<?php
/**
 * funcoes.php
 * Funções auxiliares: mensagens, autenticação, validação e coleta de dados.
 */

/** Guarda uma mensagem na sessão para ser exibida na próxima página. */
function definir_mensagem(string $tipo, string $texto): void
{
    $_SESSION['mensagem'] = ['tipo' => $tipo, 'texto' => $texto]; // tipo: sucesso | erro
}

/** Exibe (e apaga) a mensagem de feedback. Saída protegida com htmlspecialchars(). */
function exibir_mensagem(): void
{
    if (!empty($_SESSION['mensagem'])) {
        $m = $_SESSION['mensagem'];
        unset($_SESSION['mensagem']);
        echo '<div class="mensagem ' . htmlspecialchars($m['tipo'], ENT_QUOTES, 'UTF-8') . '">'
           . htmlspecialchars($m['texto'], ENT_QUOTES, 'UTF-8')
           . '</div>';
    }
}

/** Exibe uma lista de erros de validação. */
function exibir_erros(array $erros): void
{
    if (!$erros) {
        return;
    }
    echo '<div class="mensagem erro"><ul>';
    foreach ($erros as $erro) {
        echo '<li>' . htmlspecialchars($erro, ENT_QUOTES, 'UTF-8') . '</li>';
    }
    echo '</ul></div>';
}

/** Verifica se o usuário está logado. */
function esta_logado(): bool
{
    return isset($_SESSION['usuario_id']);
}

/** Redireciona para o login se não estiver autenticado. */
function exigir_login(): void
{
    if (!esta_logado()) {
        definir_mensagem('erro', 'Faça login para acessar esta página.');
        header('Location: login.php');
        exit;
    }
}

/** Lê os campos do formulário de contato (com trim). */
function coletar_dados_contato(array $post): array
{
    return [
        'nome'     => trim($post['nome']     ?? ''),
        'telefone' => trim($post['telefone'] ?? ''),
        'email'    => trim($post['email']    ?? ''),
        'empresa'  => trim($post['empresa']  ?? ''),
        'notas'    => trim($post['notas']    ?? ''),
    ];
}

/** Valida os dados do contato. Retorna array de erros (vazio = ok). */
function validar_contato(array $d): array
{
    $erros = [];

    if ($d['nome'] === '' || strlen($d['nome']) > 100) {
        $erros[] = 'Informe o nome do contato (máximo 100 caracteres).';
    }
    if ($d['email'] !== '' && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (strlen($d['telefone']) > 30) {
        $erros[] = 'Telefone muito longo (máximo 30 caracteres).';
    }
    if (strlen($d['empresa']) > 100) {
        $erros[] = 'Empresa muito longa (máximo 100 caracteres).';
    }

    return $erros;
}

/** Protege saída HTML (atalho). */
function e(?string $str): string
{
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
