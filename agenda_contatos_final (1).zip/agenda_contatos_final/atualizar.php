<?php
/**
 * atualizar.php
 * UPDATE do contato
 */
require_once 'conexao.php';
exigir_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$usuario_id = (int) $_SESSION['usuario_id'];
$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

if ($id <= 0) {
    definir_mensagem('erro', 'Contato inválido.');
    header('Location: index.php');
    exit;
}

$dados = coletar_dados_contato($_POST);
$erros = validar_contato($dados);

if ($erros) {
    // Volta para o formulário de edição com os erros
    $_SESSION['erros_edicao'] = $erros;
    $_SESSION['dados_edicao'] = $dados;
    header('Location: editar.php?id=' . $id);
    exit;
}

$stmt = $conn->prepare(
    'UPDATE contatos
     SET nome = ?, telefone = ?, email = ?, empresa = ?, notas = ?
     WHERE id = ? AND usuario_id = ?'
);
$stmt->bind_param(
    'sssssii',
    $dados['nome'],
    $dados['telefone'],
    $dados['email'],
    $dados['empresa'],
    $dados['notas'],
    $id,
    $usuario_id
);

if ($stmt->execute() && $stmt->affected_rows >= 0) {
    $stmt->close();
    definir_mensagem('sucesso', 'Contato atualizado com sucesso!');
} else {
    $stmt->close();
    definir_mensagem('erro', 'Não foi possível atualizar o contato.');
}

header('Location: index.php');
exit;
