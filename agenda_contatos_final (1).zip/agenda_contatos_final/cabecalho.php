<?php /* Cabeçalho comum. Defina $titulo_pagina antes de incluir. */ ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($titulo_pagina ?? 'Agenda') ?> - Agenda de Contatos</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
<header class="topo">
    <div class="container">
        <h1><a href="index.php">📒 Agenda de Contatos</a></h1>
        <nav>
            <?php if (esta_logado()): ?>
                <span class="usuario-logado">Olá, <?= e($_SESSION['usuario_nome'] ?? '') ?></span>
                <a href="index.php">Meus Contatos</a>
                <a href="cadastrar.php">+ Novo Contato</a>
                <a href="logout.php" class="btn-sair">Sair</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Criar conta</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="container">
<?php exibir_mensagem(); ?>
