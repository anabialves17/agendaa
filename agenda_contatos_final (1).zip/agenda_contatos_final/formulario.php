<?php
/**
 * formulario.php
 * Formulário reutilizado em cadastrar.php e editar.php
 * Variáveis esperadas: $dados (array), $acao (string), $botao (string)
 */
?>
<form method="post" action="<?= e($acao) ?>" class="formulario">
    <?php if (!empty($dados['id'])): ?>
        <input type="hidden" name="id" value="<?= (int)$dados['id'] ?>">
    <?php endif; ?>

    <div class="campo">
        <label for="nome">Nome *</label>
        <input type="text" id="nome" name="nome" required maxlength="100"
               value="<?= e($dados['nome'] ?? '') ?>" autofocus
               placeholder="Nome completo do contato">
    </div>

    <div class="campo">
        <label for="telefone">Telefone</label>
        <input type="text" id="telefone" name="telefone" maxlength="30"
               value="<?= e($dados['telefone'] ?? '') ?>"
               placeholder="(00) 00000-0000">
    </div>

    <div class="campo">
        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" maxlength="150"
               value="<?= e($dados['email'] ?? '') ?>"
               placeholder="contato@email.com">
    </div>

    <div class="campo">
        <label for="empresa">Empresa</label>
        <input type="text" id="empresa" name="empresa" maxlength="100"
               value="<?= e($dados['empresa'] ?? '') ?>"
               placeholder="Nome da empresa">
    </div>

    <div class="campo">
        <label for="notas">Notas / Observações</label>
        <textarea id="notas" name="notas" rows="4"
                  placeholder="Anotações sobre o contato..."><?= e($dados['notas'] ?? '') ?></textarea>
    </div>

    <div class="botoes">
        <button type="submit" class="btn btn-primario"><?= e($botao) ?></button>
        <a href="index.php" class="btn btn-secundario">Cancelar</a>
    </div>
</form>
