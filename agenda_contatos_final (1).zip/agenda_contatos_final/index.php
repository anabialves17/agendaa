<?php
/**
 * index.php
 * Listagem de contatos do usuário logado + busca
 */
require_once 'conexao.php';
exigir_login();

$usuario_id = (int) $_SESSION['usuario_id'];
$busca = trim($_GET['busca'] ?? '');
$termo = '%' . $busca . '%';

// Conta total de contatos do usuário
$stmtTotal = $conn->prepare('SELECT COUNT(*) AS total FROM contatos WHERE usuario_id = ?');
$stmtTotal->bind_param('i', $usuario_id);
$stmtTotal->execute();
$total = (int) $stmtTotal->get_result()->fetch_assoc()['total'];
$stmtTotal->close();

// Busca contatos
if ($busca !== '') {
    $sql = "SELECT id, nome, telefone, email, empresa, notas
            FROM contatos
            WHERE usuario_id = ?
              AND (nome LIKE ? OR telefone LIKE ? OR email LIKE ? OR empresa LIKE ?)
            ORDER BY nome ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('issss', $usuario_id, $termo, $termo, $termo, $termo);
} else {
    $sql = "SELECT id, nome, telefone, email, empresa, notas
            FROM contatos
            WHERE usuario_id = ?
            ORDER BY nome ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $usuario_id);
}

$contatos = [];
$erro_consulta = false;

if ($stmt) {
    if ($stmt->execute()) {
        $resultado = $stmt->get_result();
        $contatos = $resultado->fetch_all(MYSQLI_ASSOC);
    } else {
        $erro_consulta = true;
    }
    $stmt->close();
} else {
    $erro_consulta = true;
}

$titulo_pagina = 'Meus Contatos';
require 'cabecalho.php';
?>

<div class="page-header">
    <h2>Meus Contatos</h2>
    <span class="badge"><?= $total ?> contato(s)</span>
</div>

<form method="get" action="index.php" class="busca">
    <label for="busca" class="sr-only">Buscar</label>
    <input type="search" id="busca" name="busca"
           placeholder="Buscar por nome, telefone, e-mail ou empresa..."
           value="<?= e($busca) ?>">
    <button type="submit" class="btn btn-primario">Buscar</button>
    <?php if ($busca !== ''): ?>
        <a href="index.php" class="btn btn-secundario">Limpar</a>
    <?php endif; ?>
    <a href="cadastrar.php" class="btn btn-sucesso">+ Novo Contato</a>
</form>

<?php if ($erro_consulta): ?>
    <div class="mensagem erro">Não foi possível consultar os registros. Tente novamente.</div>
<?php elseif (!$contatos): ?>
    <div class="vazio">
        <?php if ($busca !== ''): ?>
            Nenhum contato encontrado para "<strong><?= e($busca) ?></strong>".
        <?php else: ?>
            Nenhum contato cadastrado ainda.<br>
            <a href="cadastrar.php" class="btn btn-sucesso" style="margin-top:12px;">Adicionar primeiro contato</a>
        <?php endif; ?>
    </div>
<?php else: ?>
    <p class="contagem"><?= count($contatos) ?> registro(s) encontrado(s).</p>

    <div class="tabela-wrap">
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>E-mail</th>
                    <th>Empresa</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($contatos as $c): ?>
                <tr>
                    <td><strong><?= e($c['nome']) ?></strong></td>
                    <td><?= e($c['telefone'] ?: '—') ?></td>
                    <td><?= e($c['email'] ?: '—') ?></td>
                    <td><?= e($c['empresa'] ?: '—') ?></td>
                    <td class="acoes">
                        <a href="editar.php?id=<?= (int)$c['id'] ?>" class="btn btn-pequeno btn-primario">Editar</a>
                        <form method="post" action="excluir.php" style="display:inline;"
                              onsubmit="return confirm('Tem certeza que deseja excluir este contato?');">
                            <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                            <button type="submit" class="btn btn-pequeno btn-perigo">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require 'rodape.php'; ?>
