<?php
require_once 'conexao.php';

if (esta_logado()) {
    header('Location: index.php');
    exit;
}

$erros = [];
$nome  = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = trim($_POST['nome'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $senha    = $_POST['senha'] ?? '';
    $confirma = $_POST['confirma'] ?? '';

    if ($nome === '' || strlen($nome) > 100) {
        $erros[] = 'Informe seu nome (máximo 100 caracteres).';
    }
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros[] = 'Informe um e-mail válido.';
    }
    if (strlen($senha) < 6) {
        $erros[] = 'A senha deve ter no mínimo 6 caracteres.';
    }
    if ($senha !== $confirma) {
        $erros[] = 'As senhas não coincidem.';
    }

    // Verifica se o e-mail já existe
    if (!$erros) {
        $stmt = $conn->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) {
            $erros[] = 'Este e-mail já está cadastrado.';
        }
        $stmt->close();
    }

    if (!$erros) {
        $hash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)');
        $stmt->bind_param('sss', $nome, $email, $hash);

        if ($stmt->execute()) {
            $stmt->close();
            definir_mensagem('sucesso', 'Conta criada com sucesso! Faça login.');
            header('Location: login.php');
            exit;
        } else {
            $erros[] = 'Erro ao criar a conta. Tente novamente.';
            $stmt->close();
        }
    }
}

$titulo_pagina = 'Criar Conta';
require 'cabecalho.php';
?>

<div class="auth-box">
    <h2>Criar Conta</h2>
    <p class="subtitulo">Cadastre-se para começar a usar a agenda</p>

    <?php exibir_erros($erros); ?>

    <form method="post" action="register.php" class="formulario">
        <div class="campo">
            <label for="nome">Nome completo</label>
            <input type="text" id="nome" name="nome" value="<?= e($nome) ?>" required autofocus
                   placeholder="Seu nome">
        </div>
        <div class="campo">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" value="<?= e($email) ?>" required
                   placeholder="seu@email.com">
        </div>
        <div class="campo">
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required placeholder="Mínimo 6 caracteres">
        </div>
        <div class="campo">
            <label for="confirma">Confirmar senha</label>
            <input type="password" id="confirma" name="confirma" required placeholder="Repita a senha">
        </div>
        <button type="submit" class="btn btn-primario">Cadastrar</button>
    </form>

    <p class="auth-link">Já tem conta? <a href="login.php">Fazer login</a></p>
</div>

<?php require 'rodape.php'; ?>
