</main>
<footer class="rodape">
    <div class="container">Agenda de Contatos · PHP + MySQLi (OO) · Prepared Statements · Login seguro</div>
</footer>
</body>
</html>
