<?php
require_once 'conexao.php';

// Se já estiver logado, vai para a lista
if (esta_logado()) {
    header('Location: index.php');
    exit;
}

$erros = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if ($email === '' || $senha === '') {
        $erros[] = 'Preencha e-mail e senha.';
    } else {
        $stmt = $conn->prepare('SELECT id, nome, senha FROM usuarios WHERE email = ? LIMIT 1');
        if ($stmt) {
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuario = $resultado->fetch_assoc();
            $stmt->close();

            if ($usuario && password_verify($senha, $usuario['senha'])) {
                $_SESSION['usuario_id']   = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];
                definir_mensagem('sucesso', 'Login realizado com sucesso!');
                header('Location: index.php');
                exit;
            } else {
                $erros[] = 'E-mail ou senha incorretos.';
            }
        } else {
            $erros[] = 'Erro ao consultar o banco de dados.';
        }
    }
}

$titulo_pagina = 'Login';
require 'cabecalho.php';
?>

<div class="auth-box">
    <h2>Entrar na Agenda</h2>
    <p class="subtitulo">Faça login para gerenciar seus contatos</p>

    <?php exibir_erros($erros); ?>

    <form method="post" action="login.php" class="formulario">
        <div class="campo">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" value="<?= e($email) ?>" required autofocus
                   placeholder="seu@email.com">
        </div>
        <div class="campo">
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required placeholder="••••••••">
        </div>
        <button type="submit" class="btn btn-primario">Entrar</button>
    </form>

    <p class="auth-link">Não tem conta? <a href="register.php">Criar conta</a></p>
</div>

<?php require 'rodape.php'; ?>
