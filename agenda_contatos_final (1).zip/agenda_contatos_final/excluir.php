<?php
/**
 * excluir.php
 * DELETE do contato (somente via POST)
 */
require_once 'conexao.php';
exigir_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$usuario_id = (int) $_SESSION['usuario_id'];
$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;

if ($id <= 0) {
    definir_mensagem('erro', 'Contato inválido.');
    header('Location: index.php');
    exit;
}

$stmt = $conn->prepare('DELETE FROM contatos WHERE id = ? AND usuario_id = ?');
$stmt->bind_param('ii', $id, $usuario_id);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    definir_mensagem('sucesso', 'Contato excluído com sucesso!');
} else {
    definir_mensagem('erro', 'Não foi possível excluir o contato.');
}
$stmt->close();

header('Location: index.php');
exit;
