-- ============================================================
-- Agenda de Contatos - Script de criação do banco
-- Execute este arquivo no phpMyAdmin (Importar) ou no HeidiSQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS agenda_contatos
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE agenda_contatos;

-- Tabela de usuários (login)
CREATE TABLE IF NOT EXISTS usuarios (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    senha      VARCHAR(255) NOT NULL,
    criado_em  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de contatos
CREATE TABLE IF NOT EXISTS contatos (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id     INT NOT NULL,
    nome           VARCHAR(100) NOT NULL,
    telefone       VARCHAR(30)  DEFAULT NULL,
    email          VARCHAR(150) DEFAULT NULL,
    empresa        VARCHAR(100) DEFAULT NULL,
    notas          TEXT         DEFAULT NULL,
    criado_em      DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usuário de exemplo (senha: 123456)
-- O hash abaixo corresponde a password_hash('123456', PASSWORD_DEFAULT)
INSERT INTO usuarios (nome, email, senha) VALUES
('Usuário Demo', 'demo@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
-- Observação: o hash acima é apenas exemplo. Crie sua conta pela tela de cadastro.
