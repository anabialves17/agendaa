<?php
/**
 * conexao.php
 * Conexão com o banco de dados usando mysqli ORIENTADO A OBJETOS.
 * Este arquivo é incluído (require_once) em todas as páginas.
 */

// Desliga o modo "lança exceção" do PHP 8.1+, para que possamos tratar
// a falha de conexão manualmente com connect_errno.
mysqli_report(MYSQLI_REPORT_OFF);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- Configurações (Laragon / XAMPP padrão) ----
$host    = 'localhost';
$usuario = 'root';
$senha   = '';               // Laragon e XAMPP: senha vazia
$banco   = 'agenda_contatos';

// ---- Conexão OO ----
$conn = new mysqli($host, $usuario, $senha, $banco);

// ---- Tratamento de falha de conexão ----
if ($conn->connect_errno) {
    http_response_code(500);
    die(
        'Falha na conexão com o banco de dados (erro ' .
        htmlspecialchars((string) $conn->connect_errno, ENT_QUOTES, 'UTF-8') . '): ' .
        htmlspecialchars($conn->connect_error, ENT_QUOTES, 'UTF-8') .
        '<br><br>Verifique se o banco <strong>agenda_contatos</strong> foi criado (execute o arquivo banco.sql).'
    );
}

// Charset correto para acentuação
$conn->set_charset('utf8mb4');

require_once __DIR__ . '/funcoes.php';
