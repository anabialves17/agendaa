<?php
/**
 * cadastrar.php
 * INSERT de novo contato
 */
require_once 'conexao.php';
exigir_login();

$usuario_id = (int) $_SESSION['usuario_id'];
$erros = [];
$dados = [
    'nome' => '', 'telefone' => '', 'email' => '', 'empresa' => '', 'notas' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dados = coletar_dados_contato($_POST);
    $erros = validar_contato($dados);

    if (!$erros) {
        $stmt = $conn->prepare(
            'INSERT INTO contatos (usuario_id, nome, telefone, email, empresa, notas)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->bind_param(
            'isssss',
            $usuario_id,
            $dados['nome'],
            $dados['telefone'],
            $dados['email'],
            $dados['empresa'],
            $dados['notas']
        );

        if ($stmt->execute()) {
            $stmt->close();
            definir_mensagem('sucesso', 'Contato cadastrado com sucesso!');
            header('Location: index.php');
            exit;
        } else {
            $erros[] = 'Erro ao salvar o contato. Tente novamente.';
            $stmt->close();
        }
    }
}

$titulo_pagina = 'Novo Contato';
require 'cabecalho.php';
?>

<h2>Novo Contato</h2>

<?php
exibir_erros($erros);
$acao = 'cadastrar.php';
$botao = 'Cadastrar Contato';
require 'formulario.php';
?>

<?php require 'rodape.php'; ?>
