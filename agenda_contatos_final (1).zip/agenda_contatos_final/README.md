# 📒 Agenda de Contatos — PHP + MySQLi (Orientado a Objetos)

Sistema de gestão de agenda de contatos com **login e senha**, desenvolvido em **PHP puro** com **MySQL**, aplicando boas práticas de segurança contra **SQL Injection** e **XSS**.

---

## 🎯 Objetivo

Demonstrar domínio das quatro operações do CRUD + autenticação de usuários.

| # | Operação | Onde está implementada |
|---|----------|------------------------|
| 1 | **INSERT** (Create) | `register.php` (usuário) e `cadastrar.php` (contato) |
| 2 | **SELECT** (Read)   | `index.php` (listagem + busca) e `login.php` |
| 3 | **UPDATE** (Update)  | `editar.php` → `atualizar.php` |
| 4 | **DELETE** (Delete)  | `excluir.php` (somente POST) |
| 5 | **Login / Sessão**   | `login.php`, `logout.php`, função `exigir_login()` |

---

## 🧰 Tecnologias

- PHP 8+
- MySQL / MariaDB
- Extensão **mysqli** orientada a objetos
- HTML5 + CSS3 (sem frameworks)
- Sessões PHP + `password_hash` / `password_verify`

---

## ⚙️ Como executar no Laragon

1. **Copie a pasta** `agenda_contatos_final` para:
   ```
   C:\laragon\www\
   ```
   (pode renomear para `agenda-contatos` se preferir)

2. **Inicie o Laragon** (Start All)

3. **Crie o banco de dados**:
   - Abra o HeidiSQL ou phpMyAdmin
   - Importe o arquivo `banco.sql`
   - (ou execute o conteúdo dele)

4. **Acesse**:
   - `http://agenda_contatos_final.test`
   - ou `http://localhost/agenda_contatos_final`

5. **Crie sua conta** na tela de cadastro e comece a usar.

> As credenciais padrão do Laragon (`root` sem senha) já estão configuradas em `conexao.php`.

---

## 📁 Estrutura de arquivos

```
agenda_contatos_final/
├── conexao.php      → Conexão mysqli OO + session_start
├── funcoes.php      → Funções auxiliares (mensagens, validação, login)
├── banco.sql        → Script de criação do banco e tabelas
│
├── login.php        → Tela de login
├── register.php     → Cadastro de usuário
├── logout.php       → Encerra a sessão
│
├── index.php        → Listagem + busca de contatos
├── cadastrar.php    → INSERT de contato
├── editar.php       → Carrega contato para edição
├── atualizar.php    → UPDATE do contato
├── excluir.php      → DELETE do contato
│
├── formulario.php   → Formulário reutilizado
├── cabecalho.php    → Topo HTML comum
├── rodape.php       → Rodapé HTML comum
├── estilo.css       → Estilos
└── README.md
```

---

## 🗄️ Tabelas do banco

**usuarios**
- id, nome, email (único), senha (hash), criado_em

**contatos**
- id, usuario_id (FK), nome, telefone, email, empresa, notas, criado_em, atualizado_em

Cada contato pertence a um usuário (`FOREIGN KEY` + `ON DELETE CASCADE`).

---

## 🔒 Segurança aplicada

- Senhas com `password_hash()` / `password_verify()`
- Prepared Statements em todas as queries
- `htmlspecialchars()` em todas as saídas
- Exclusão somente via POST
- Verificação de dono do contato (`usuario_id`) em UPDATE e DELETE
- Páginas protegidas com `exigir_login()`
