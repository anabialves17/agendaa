<?php
/**
 * editar.php
 * Carrega o contato e exibe o formulário pré-preenchido
 */
require_once 'conexao.php';
exigir_login();

$usuario_id = (int) $_SESSION['usuario_id'];
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id <= 0) {
    definir_mensagem('erro', 'Contato inválido.');
    header('Location: index.php');
    exit;
}

// Busca o contato garantindo que pertence ao usuário logado
$stmt = $conn->prepare(
    'SELECT id, nome, telefone, email, empresa, notas
     FROM contatos
     WHERE id = ? AND usuario_id = ?
     LIMIT 1'
);
$stmt->bind_param('ii', $id, $usuario_id);
$stmt->execute();
$resultado = $stmt->get_result();
$dados = $resultado->fetch_assoc();
$stmt->close();

if (!$dados) {
    definir_mensagem('erro', 'Contato não encontrado ou você não tem permissão.');
    header('Location: index.php');
    exit;
}

$titulo_pagina = 'Editar Contato';
require 'cabecalho.php';
?>

<h2>Editar Contato</h2>

<?php
$acao = 'atualizar.php';
$botao = 'Salvar Alterações';
require 'formulario.php';
?>

<?php require 'rodape.php'; ?>
